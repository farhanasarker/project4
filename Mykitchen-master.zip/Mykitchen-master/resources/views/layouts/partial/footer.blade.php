<!-- Footer -->
<footer class="footer">
  <div class="container-fluid">
    <div class="copyright pull-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, made with <i class="material-icons">favorite</i> by
      <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> and developed by Sumaia Zaman for a better web.
    </div>
  </div>
</footer>
<!-- End Footer -->